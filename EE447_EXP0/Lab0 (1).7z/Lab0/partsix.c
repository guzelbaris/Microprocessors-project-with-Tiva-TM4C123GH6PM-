/********************* 
* Writed_version-of1.10.c  
* Writes inputs as outputs on Termite 3.4
*********************
* Reference external subroutine with full signature */
extern void OutChar(char); 
extern char InChar(void);

int main(void){	/* It's void there is no return in this case */
	/* allocate memory for data                            */
	char input;	/*input decleration */

	while(1){	/*infinite loop since inside is always 1 */

		input= InChar(); /* We take input from previously created InChar function */
			if (input==0x20) { /* note that 0*20 = SPACEBAR in ASCII table */
				while(1){}
		}
		OutChar(input); /* print output */
	}
}